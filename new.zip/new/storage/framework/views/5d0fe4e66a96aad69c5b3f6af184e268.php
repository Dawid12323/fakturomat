

<?php $__env->startSection('content'); ?>
       
        <section class="page-section masthead" id="contact">
            <div class="container">
                
                <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Edytuj fakturę <?php echo e($invoice->id); ?></h2>
                
                <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-xl-7">
                        <form action="<?php echo e(route('invoices.update', ['id' => $invoice->id])); ?>" method="POST" id="contactForm" data-sb-form-api-token="API_TOKEN">
                            <?php echo e(csrf_field()); ?>

                            <?php echo method_field('PUT'); ?>
                            <div class="form-floating mb-3">
                                <input value="<?php echo e($invoice->number); ?>" class="form-control" id="number" name="number" type="text" placeholder="Numer faktury" data-sb-validations="required" />
                                <label for="name">Numer faktury</label>
                                <div class="invalid-feedback" data-sb-feedback="name:required">Wpisz numer faktury.</div>
                            </div>

                            <div class="form-floating mb-3">
                                <input value="<?php echo e($invoice->date); ?>" class="form-control" id="date" name="date" type="text" placeholder="Data wystawienia" data-sb-validations="required,email" />
                                <label for="email">Data wystawienia</label>
                                <div class="invalid-feedback" data-sb-feedback="email:required">Wprowadź datę.</div>
                                <div class="invalid-feedback" data-sb-feedback="email:email">Nieprawidłowa data.</div>
                            </div>

                            <div class="form-floating mb-3">
                                <input value="<?php echo e($invoice->total); ?>" class="form-control" id="total" name="total" type="text" placeholder="Kwota faktury" data-sb-validations="required" />
                                <label for="phone">Kwota</label>
                                <div class="invalid-feedback" data-sb-feedback="phone:required">Kwota jest wymagana.</div>
                            </div>
                           
                        </div>
                            <div id="success"></div>
                            <button onclick="displayInput()" class="btn btn-primary btn-xl" id="submitButton" type="submit">Zapisz</button>   
                            <p id="output"></p>
                        </form>
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dawid\new\resources\views/invoices/edit.blade.php ENDPATH**/ ?>