@extends('layouts.app')

@section('content')
       
        <section class="page-section masthead" id="contact">
            <div class="container">
                
                <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Dodaj fakturę</h2>
                
                <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-xl-7">
                        <form action="{{route('invoices.store')}}" method="POST" id="contactForm" data-sb-form-api-token="API_TOKEN">
                            {{ csrf_field() }}
                            <div class="form-floating mb-3">
                                <input class="form-control" id="number" name="number" type="number" placeholder="Numer faktury" data-sb-validations="required" />
                                <label for="name">Numer faktury</label>
                                <div class="invalid-feedback" data-sb-feedback="name:required">Wpisz numer faktury.</div>
                            </div>

                            <div class="form-floating mb-3">
                                <input class="form-control" id="date" name="date" type="date" placeholder="Data wystawienia" data-sb-validations="required,email" />
                                <label for="email">Data wystawienia</label>
                                <div class="invalid-feedback" data-sb-feedback="email:required">Wprowadź datę.</div>
                                <div class="invalid-feedback" data-sb-feedback="email:email">Nieprawidłowa data.</div>
                            </div>

                            <div class="form-floating mb-3">
                                <input class="form-control" id="total" name="total" type="number" placeholder="Kwota faktury" data-sb-validations="required" />
                                <label for="phone">Kwota</label>
                                <div class="invalid-feedback" data-sb-feedback="phone:required">Kwota jest wymagana.</div>
                            </div>

                            </div>
                            <div id="success"></div>
                            <button onclick="displayInput()" class="btn btn-primary btn-xl" id="submitButton" type="submit">Prześlij</button>   
                            <p id="output"></p>


                            {{-- <div class="form-floating mb-3">
                                <input class="form-control" id="netto" name="netto" type="number" placeholder="Kwota netto" data-sb-validations="required" />
                                <label for="netto">Kwota netto</label>
                                <p id="result"></p>
                                <script>
                                    const input = document.getElementById("netto");
                                    const result = document.getElementById("result");
            
                                    input.addEventListener("input", function()
                                    {
                                        if(isNaN(this.value))
                                        {
                                            result.textContent = "To nie jest liczba";
                                        }
                                        else
                                        {
                                            result.textContent = "To jest liczba";
                                        }
                                    });
                                    </script>
                            </div>
                           
                            <div class="form-floating mb-3">
                                <input class="form-control" id="vat" name="vat" type="number" placeholder="Kwota VAT" data-sb-validations="required" />
                                <label for="vat">Kwota VAT</label>
                                <p id="result"></p>

                                <script>
                                    const vat = document.getElementById("vat-input");
                                    const validation = document.getElementById("validation-message");

                                    vat.addEventListener("input", function()
                                    {
                                        if (validatePercentageInput(this.value))
                                        {
                                            validation.textContent = "Podana wartość nie jest poprawna";
                                        }
                                        else
                                        {
                                            validation.textContent = "Podana wartość jest poprawna";

                                        }
                                    });
                                </script>
                            </div>--}}

                            {{-- <div id="success"></div>
                            <button onclick="calculate()" class="btn btn-primary btn-xl" id="submitButton" type="submit">Oblicz kwotę brutto</button>
                            <p id="output"></p> --}}
                            

                            {{-- <div class="form-floating mb-3">
                                <input class="form-control" id="brutto" name="brutto" type="numer" placeholder="Kwota VAT" data-sb-validations="required" />
                                <label for="brutto">Kwota brutto</label>
                                <p id="brutto"></p>
                                <script>
                                    function calculate() {
                                      const nettoInput = document.getElementById("netto");
                                      const vatInput = document.getElementById("vat");
                                      const bruttoOutput = document.getElementById("brutto");
                                  
                                      const netto = parseFloat(nettoInput.value);
                                      const vat = parseFloat(vatInput.value);
                                  
                                      const brutto = netto * (1 + vat / 100);
                                  
                                      bruttoOutput.textContent = `Kwota brutto wynosi: ${brutto.toFixed(2)} zł`;
                                    }
                                  </script>
                            </div> --}}


                            <div class="form-floating mb-3">
                                <div class="form-floating mb-3">
                                <input class="form-control" id="netto" name="netto" type="number" placeholder="Kwota netto" data-sb-validations="required" />
                                <label for="netto">Kwota netto</label>
                                <p id="result"></p>
                                </div>
                                <div class="form-floating mb-3">
                                <input class="form-control" id="vat" name="vat" type="number" placeholder="Kwota VAT" data-sb-validations="required" />
                                <label for="vat">Kwota VAT</label>
                                <p id="validation"></p>
                                </div>
                            </div>
                                <div id="success"></div>
                                <button onclick="calculate()" class="btn btn-primary btn-xl" id="submitButton" type="submit">Oblicz kwotę brutto</button>                       
                                <p id="brutto"></p>
                                
                                <script>
                                  function calculate() {
                                    const nettoInput = document.getElementById("netto");
                                    const vatInput = document.getElementById("vat");
                                    const bruttoOutput = document.getElementById("brutto");
                                
                                    const netto = parseFloat(nettoInput.value);
                                    const vat = parseFloat(vatInput.value);
                                
                                    const brutto = netto * (1 + vat / 100);
                                
                                    bruttoOutput.textContent = `Kwota brutto wynosi: ${brutto.toFixed(2)} zł`;
                                  }
                                </script>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
@endsection