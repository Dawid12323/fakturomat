{{-- <?php 
// $conn = new mysqli("localhost", "root", "", "fakturomat") or die("Error");
// $wynik = $conn->query("SELECT * FROM `faktury`");

// if($wynik->num_rows > 0){

//     echo "<table>";

//     while( $wiersz = $wynik->fetch_assoc()){
//         echo "<tr>";
//         echo "<td>" . $wiersz["numer faktury"] . "</td>";
//         echo "<td>" . $wiersz["data wystawienia"] ."</td>";
//         echo "<td>" . $wiersz["netto"] . "</td>";
    
//         echo "<tr>";
//     }
//     echo "</table>";

// }else {

//     echo "Nie ma faktury w bazie danych";
// }
// $conn->close();
?> --}}